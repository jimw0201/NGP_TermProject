#ifndef SHADER_H
#define SHADER_H

#include <gl/glew.h>

extern GLuint shaderProgramID;

void Shader_InitAll();

#endif