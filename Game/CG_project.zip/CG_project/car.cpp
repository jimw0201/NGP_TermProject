#include "car.h"
#include "mesh.h"

static float car_dx, car_dy, car_dz;
static float car_rotateY;

static float front_wheels_rotateY;
static float wheel_rect_rotateX;

static float car_speed;
static bool isAcceleratingForward;
static bool isAcceleratingBackward;
static bool isBraking;

static const float MAX_SPEED = 0.01f;
static const float acceleration = 0.001f;
static const float deceleration = 0.005f;
static const float friction = 0.0001f;

void Car_UpdateSpeed(GearState currentGear)
{
	if (currentGear == PARK || currentGear == NEUTRAL)
	{
		car_speed = 0.0f; // ����
	}

	// ���� ó��
	if (currentGear == REVERSE && isAcceleratingBackward)
	{
		car_speed -= acceleration;
		if (car_speed < -MAX_SPEED)
			car_speed = -MAX_SPEED;
	}

	// ���� ó��
	if (currentGear == DRIVE && isAcceleratingForward)
	{
		car_speed += acceleration;
		if (car_speed > MAX_SPEED)
			car_speed = MAX_SPEED;
	}

	if (isBraking)
	{
		if (car_speed > 0.0f)
		{
			car_speed -= deceleration;
			if (car_speed < 0.0f)
				car_speed = 0.0f;
		}
		else if (car_speed < 0.0f)
		{
			car_speed += deceleration;
			if (car_speed > 0.0f)
				car_speed = 0.0f;
		}
	}

	if (!isAcceleratingForward && !isAcceleratingBackward && !isBraking)
	{
		// �ڿ� ����
		if (car_speed > 0.0f)
		{
			car_speed -= friction;
			if (car_speed < 0.0f)
				car_speed = 0.0f;
		}
		else if (car_speed < 0.0f)
		{
			car_speed += friction;
			if (car_speed > 0.0f)
				car_speed = 0.0f;
		}
	}
}

void Car_Init()
{
    car_dx = 0.0f;
    car_dy = WHEEL_SIZE;
    car_dz = -3.0f;
    car_rotateY = 0.0f;

    front_wheels_rotateY = 0.0f;
    wheel_rect_rotateX = 0.0f;

    car_speed = 0.0f;
    isAcceleratingForward = false;
    isAcceleratingBackward = false;
    isBraking = false;
}

// ��ü�� ��ȯ - �̸� �������� ������Ʈ, ���� ���� ��ġ�� ��������.
glm::mat4 Car_Body()
{
	glm::mat4 T = glm::mat4(1.0f);
	glm::mat4 Ry = glm::mat4(1.0f);
	//glm::mat4 S = glm::mat4(1.0f);

	Ry = glm::rotate(Ry, glm::radians(car_rotateY), glm::vec3(0.0, 1.0, 0.0));
	T = glm::translate(T, glm::vec3(car_dx, car_dy, car_dz));

	return T * Ry;
}
glm::mat4 Headlights(int left_right)
{
	glm::mat4 T = glm::mat4(1.0f);
	glm::mat4 Ry = glm::mat4(1.0f);
	//glm::mat4 S = glm::mat4(1.0f);

	if (left_right == 0)
	{
		T = glm::translate(T, glm::vec3(-CAR_SIZE / 3, CAR_SIZE / 8, CAR_SIZE));
	}
	else if (left_right == 1)
	{
		T = glm::translate(T, glm::vec3(CAR_SIZE / 3, CAR_SIZE / 8, CAR_SIZE));
	}

	return Car_Body() * T;
}

// ���� ��ȯ - �չ��� ȸ��
glm::mat4 Wheels(int num)
{
	glm::mat4 T2 = glm::mat4(1.0f);
	if (num == 1) //�� ���� ���� ��
	{
		T2 = glm::translate(T2, glm::vec3(-(CAR_SIZE / 2 + WHEEL_SIZE / 4), 0.0f, CAR_SIZE * 0.5f));
	}
	if (num == 2) //������ ��
	{
		T2 = glm::translate(T2, glm::vec3(CAR_SIZE / 2 + WHEEL_SIZE / 4, 0.0f, CAR_SIZE * 0.5f));
	}
	if (num == 3) //���� ��
	{
		T2 = glm::translate(T2, glm::vec3(-(CAR_SIZE / 2 + WHEEL_SIZE / 4), 0.0f, -CAR_SIZE * 0.5f));
	}
	if (num == 4)  //������ ��
	{
		T2 = glm::translate(T2, glm::vec3(CAR_SIZE / 2 + WHEEL_SIZE / 4, 0.0f, -CAR_SIZE * 0.5f));
	}
	return Car_Body() * T2;
}
glm::mat4 Wheel_rects(int num)
{
	glm::mat4 T = glm::mat4(1.0f);
	glm::mat4 T2 = glm::mat4(1.0f);
	glm::mat4 Ry = glm::mat4(1.0f);

	if (num == 1 || num == 2)
	{
		//�չ����鿡�� ȸ�� ��ȯ �߰� ����
		Ry = glm::rotate(Ry, glm::radians(front_wheels_rotateY), glm::vec3(0.0, 1.0, 0.0));
	}
	if (num == 1) //�� ���� ���� ��
	{
		T = glm::translate(T, glm::vec3(-(0.001f), 0.0f, 0.0f));
		T2 = glm::translate(T2, glm::vec3(-(CAR_SIZE / 2 + WHEEL_SIZE / 4), 0.0f, CAR_SIZE * 0.5f));
	}
	if (num == 2) //������ ��
	{
		T = glm::translate(T, glm::vec3((0.001f), 0.0f, 0.0f));
		T2 = glm::translate(T2, glm::vec3(CAR_SIZE / 2 + WHEEL_SIZE / 4, 0.0f, CAR_SIZE * 0.5f));
	}
	if (num == 3) //���� ��
	{
		T = glm::translate(T, glm::vec3(-(0.001f), 0.0f, 0.0f));
		T2 = glm::translate(T2, glm::vec3(-(CAR_SIZE / 2 + WHEEL_SIZE / 4), 0.0f, -CAR_SIZE * 0.5f));
	}
	if (num == 4)  //������ ��
	{
		T = glm::translate(T, glm::vec3((0.001f), 0.0f, 0.0f));
		T2 = glm::translate(T2, glm::vec3(CAR_SIZE / 2 + WHEEL_SIZE / 4, 0.0f, -CAR_SIZE * 0.5f));
	}

	glm::mat4 Rx = glm::mat4(1.0f);
	Rx = glm::rotate(Rx, glm::radians(wheel_rect_rotateX), glm::vec3(1.0, 0.0, 0.0));

	return Car_Body() * T2 * Ry * Rx * T;
}
glm::mat4 Wheel_on_000(int num, int type) //num�� 4�� ������ ��ȣ, type�� �Ǹ���, �Ѳ� ��ü ����
{
	glm::mat4 T = glm::mat4(1.0f);
	glm::mat4 Ry = glm::mat4(1.0f);
	glm::mat4 Ry2 = glm::mat4(1.0f);
	//glm::mat4 S = glm::mat4(1.0f);

	Ry = glm::rotate(Ry, glm::radians(90.0f), glm::vec3(0.0, 1.0, 0.0));
	if (num == 1 || num == 2)
	{
		//�չ����鿡�� ȸ�� ��ȯ �߰� ����
		Ry2 = glm::rotate(Ry2, glm::radians(front_wheels_rotateY), glm::vec3(0.0, 1.0, 0.0));
	}
	if (type == 0)		//����
	{
		T = glm::translate(T, glm::vec3(0.0f, 0.0f, -WHEEL_SIZE / 4));
	}
	else if (type == 1) //���� ����1
	{
		T = glm::translate(T, glm::vec3(0.0f, 0.0f, -WHEEL_SIZE / 4));
	}
	else if (type == 2) //���� ����2
	{
		T = glm::translate(T, glm::vec3(0.0f, 0.0f, WHEEL_SIZE / 4));
	}

	return Wheels(num) * Ry2 * Ry * T;
}

std::vector<std::pair<float, float>> Car_GetRotatedCorners(float x, float z, float angle)
{
	float halfWidth = CAR_SIZE / 2;
	float halfHeight = CAR_SIZE;

	// �������� ��� ��ǥ
	std::vector<std::pair<float, float>> corners = {
		{-halfWidth, -halfHeight}, // ���ϴ�
		{halfWidth, -halfHeight},  // ���ϴ�
		{halfWidth, halfHeight},   // ����
		{-halfWidth, halfHeight}   // �»��
	};

	// ȸ�� ����(����)
	float radians = glm::radians(-angle);

	// ȸ���� ������ ��ǥ
	std::vector<std::pair<float, float>> rotatedCorners;
	for (const auto& corner : corners)
	{
		float rotatedX = corner.first * cos(radians) - corner.second * sin(radians);
		float rotatedZ = corner.first * sin(radians) + corner.second * cos(radians);
		rotatedCorners.emplace_back(x + rotatedX, z + rotatedZ);
	}
	return rotatedCorners;
}

std::vector<std::pair<float, float>> Car_GetRotatedCorners()
{
	return Car_GetRotatedCorners(car_dx, car_dz, car_rotateY);
}



float Car_GetDX() { return car_dx; }
float Car_GetDY() { return car_dy; }
float Car_GetDZ() { return car_dz; }
float Car_GetRotationY() { return car_rotateY; }
float Car_GetFrontWheelRotationY() { return front_wheels_rotateY; }
float Car_GetWheelRotationX() { return wheel_rect_rotateX; }
float Car_GetSpeed() { return car_speed; }
bool  Car_IsAcceleratingForward() { return isAcceleratingForward; }
bool  Car_IsAcceleratingBackward() { return isAcceleratingBackward; }
bool  Car_IsBraking() { return isBraking; }

void Car_SetPosition(float dx, float dz)
{
	car_dx = dx;
	car_dz = dz;
}

void Car_SetRotationY(float angle) { car_rotateY = angle; }
void Car_SetFrontWheelRotationY(float angle) { front_wheels_rotateY = angle; }
void Car_SetWheelRotationX(float angle) { wheel_rect_rotateX = angle; }
void Car_SetSpeed(float speed) { car_speed = speed; }
void Car_SetAcceleratingForward(bool status) { isAcceleratingForward = status; }
void Car_SetAcceleratingBackward(bool status) { isAcceleratingBackward = status; }
void Car_SetBraking(bool status) { isBraking = status; }