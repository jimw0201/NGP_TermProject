#include "game_state.h"
#include <gl/glew.h>
#include "car.h"
#include "input_handle.h"
#include "collision.h"
#include "environment.h"
#include "mesh.h"
#include <iostream>     
#include <gl/freeglut.h>
#include <ctime>
#include <cmath>

// --- Private ���� ���� ---
static time_t startTime;
static time_t pauseTime;
static time_t tempTime;
static int elapsedSeconds = 0;
static bool crushed = false;
static bool invincible = false;
static GearState currentGear = DRIVE;
static bool isParked = false;
static int current_stage = 1;
static bool pause_mode = false;
static bool isClear = false;


// --- �Լ� ���� ---
void GameState_Init()
{
    startTime = time(nullptr);
    pauseTime = startTime - time(nullptr);
    elapsedSeconds = 0;
    crushed = false;
    invincible = false;
    currentGear = DRIVE;
    isParked = false;
    current_stage = 1;
    pause_mode = false;
    isClear = false;
}

void GameState_NextStage()
{
	// 1. ���� �� �Է� �ʱ�ȭ
	Car_SetRotationY(0.0f);
	Car_SetFrontWheelRotationY(0.0f);
	Car_SetWheelRotationX(0.0f);

	Input_ResetHandle();

	// 2. ��� �� �ð� �ʱ�ȭ
	GameState_SetCurrentGear(DRIVE);
	GameState_UpdateStartTime(time(nullptr));
	GameState_UpdatePauseTime(GameState_GetStartTime() - time(nullptr));

	// 3. ���� �ʱ�ȭ
	GameState_SetCrushed(false);
	GameState_SetClear(false);
	GameState_SetParked(false);
	GameState_SetPaused(false);

	// 4. ���������� ����
	if (current_stage == 1)
	{
		current_stage++;

		// ȯ��(��) ����
		Environment_SetupStage(2);

		// �� ��ġ ����
		Car_SetPosition(2.0f, -4.0f);
	}
	else if (current_stage == 2)
	{
		current_stage++;

		Environment_SetupStage(3);

		Car_SetPosition(-4.0f, -4.0f);
	}
	else if (current_stage == 3)
	{
		std::cout << "--Clear!!!--\n";
		glutLeaveMainLoop(); // ���� ����
	}
}

void GameState_TimerLoop(int value)
{
    time_t currentTime = time(nullptr); // ���� ������ ����

    if (!GameState_IsPaused())
    {
        GameState_SetElapsedSeconds(static_cast<int>(currentTime - GameState_GetPauseTime() - GameState_GetStartTime()));
    }

    Car_UpdateSpeed(GameState_GetCurrentGear());

    // ������ ������ ���
    auto carCorners = Car_GetRotatedCorners();
    // ���� ���� ������Ʈ
    Environment_UpdateParkingStatus(carCorners);

    if (Car_GetSpeed() != 0.0f)
    {
        float radians = glm::radians(Car_GetRotationY());
        float new_dx = Car_GetDX() + Car_GetSpeed() * sin(radians);
        float new_dz = Car_GetDZ() + Car_GetSpeed() * cos(radians);

        const float n = 2.0f;
        float newAngle = Car_GetRotationY() + Car_GetFrontWheelRotationY() * n * Car_GetSpeed();

        auto futureCarCorners = Car_GetRotatedCorners(new_dx, new_dz, newAngle);

        bool isColliding = false;
        if (!GameState_IsInvincible())
        {
            // ������ �浹 ���� Ȯ��
            for (int i = 0; i < 4; ++i)
            {
                // �� �����ʹ� environment.h�� mesh.h�� ����� ���ϴ�.
                // GROUND_SIZE, WALL_THICKNESS ����� ���� mesh.h ���� �ʿ��� �� ���� (Car_Init ��� �̹� ����)
                float wallX = (i % 2 == 0) ? 0.0f : (i == 1 ? GROUND_SIZE : -GROUND_SIZE);
                float wallZ = (i % 2 == 1) ? 0.0f : (i == 2 ? GROUND_SIZE : -GROUND_SIZE);
                float wallWidth = (i % 2 == 0) ? GROUND_SIZE * 2 : WALL_THICKNESS;
                float wallHeight = (i % 2 == 1) ? GROUND_SIZE * 2 : WALL_THICKNESS;

                if (checkCollisionWalls(futureCarCorners, wallX, wallZ, wallWidth, wallHeight))
                {
                    isColliding = true;
                    break;
                }
            }

            if (checkCollisionObstacle(futureCarCorners))
            {
                isColliding = true;
            }
        }

        if (!isColliding)
        {
            Car_SetRotationY(newAngle);
            Car_SetPosition(new_dx, new_dz);
            float newWheelAngle = Car_GetWheelRotationX() + Car_GetSpeed() * 200.0f;
            Car_SetWheelRotationX(newWheelAngle);
        }
        else
        {
            GameState_SetCrushed(true);
            Car_SetSpeed(0.0f);
        }

        // �ڵ�� ���� ���� ����
        Input_UpdateHandleReturn();
    }

    // ȭ�� ���� ��û �� Ÿ�̸� �缳��
    glutPostRedisplay();
    // ��� ȣ�� �� �ڱ� �ڽ�(GameState_TimerLoop)�� ȣ��
    glutTimerFunc(16, GameState_TimerLoop, 1); // TIMER_VELOCITY ��� 16 ���� ����ϰų� ����� ����
}

// --- Getters ---
bool GameState_IsPaused() { return pause_mode; }
bool GameState_IsClear() { return isClear; }
bool GameState_IsParked() { return isParked; }
GearState GameState_GetCurrentGear() { return currentGear; }
time_t GameState_GetStartTime() { return startTime; }
time_t GameState_GetPauseTime() { return pauseTime; }
time_t GameState_GetTempTime() { return tempTime; }
int GameState_GetCurrentStage() { return current_stage; }
int GameState_GetElapsedSeconds() { return elapsedSeconds; }
bool GameState_IsInvincible() { return invincible; }
bool GameState_IsCrushed() { return crushed; }


// --- Setters ---
void GameState_SetPaused(bool paused) { pause_mode = paused; }
void GameState_SetClear(bool clear) { isClear = clear; }
void GameState_SetParked(bool parked) { isParked = parked; }
void GameState_SetCurrentGear(GearState gear) { currentGear = gear; }
void GameState_UpdateStartTime(time_t time) { startTime = time; }
void GameState_UpdatePauseTime(time_t time) { pauseTime = time; }
void GameState_UpdateTempTime(time_t time) { tempTime = time; }
void GameState_SetCurrentStage(int stage) { current_stage = stage; }
void GameState_SetElapsedSeconds(int seconds) { elapsedSeconds = seconds; }
void GameState_SetInvincible(bool newStatus) { invincible = newStatus; }
void GameState_SetCrushed(bool newStatus) { crushed = newStatus; }